# Exercise Story: Query Memberships

## Goal

As a gym employee, I want to query memberships separately from membership commands so that read logic stays simple and does not interfere with lifecycle behavior.

## Trigger

Examples:

- `GET /memberships`
- `GET /memberships/{membershipId}`

## Input

Optional query parameters:

- customer id
- status
- plan id

## Preconditions

None, except when querying by id:
- membership must exist, otherwise return `404 Not Found`.

## Business Rules

- Querying memberships must not change membership state.
- Query logic should not contain lifecycle rules.
- Query responses may use read-specific DTOs.
- Query models may include derived display information.
- Queries should not call the external invoice provider unless explicitly required.

## Expected Result

- Membership data is returned.
- No state changes happen.

## Suggested Implementation Tasks

- Create query endpoint or query handler.
- Load membership data.
- Map to read response.
- Return result.

## Architecture Discussion Points

- This is a preparation for CQRS.
- Commands change state.
- Queries read state.
- CQRS is useful only when the separation reduces complexity.
