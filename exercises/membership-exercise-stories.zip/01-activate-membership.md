# Exercise Story: Activate Membership

## Goal

As a gym employee, I want to activate a membership for a customer so that the customer can start training immediately and the first invoice is created.

## Trigger

`POST /memberships/activate`

## Input

- `customerId`
- `planId`
- `signedByCustodian`

## Preconditions

- Customer must exist.
- Plan must exist.
- If the customer is younger than 18, `signedByCustodian` must be `true`.

## Business Rules

- A new membership starts immediately.
- `startDate` is today.
- `endDate` is calculated from the plan duration.
- The membership status is `ACTIVE`.
- The membership stores:
  - customer id
  - plan id
  - plan price
  - plan duration
  - start date
  - end date
- An external invoice is created for the membership.
- The invoice due date is today plus 30 days.
- The membership stores only a local billing reference, not the full external invoice.
- The billing reference starts with status `OPEN`.
- An invoice email is sent to the customer.

## Expected Result

- Membership is created.
- Billing reference is created.
- External invoice is created.
- Email is sent.
- Response contains membership data and billing reference data.

## Suggested Implementation Tasks

- Validate customer existence.
- Validate plan existence.
- Check custodian signature rule.
- Create membership.
- Create external invoice.
- Create billing reference.
- Send invoice email.
- Return activation response.

## Architecture Discussion Points

- Which parts are presentation logic?
- Which parts are business rules?
- Which parts are gateway/infrastructure interactions?
- Should invoice creation and email sending be inside the same use case?
