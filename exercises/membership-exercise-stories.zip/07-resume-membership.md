# Exercise Story: Resume Membership

## Goal

As a gym employee, I want to resume a paused membership so that the customer can continue training.

## Trigger

`POST /memberships/{membershipId}/resume`

## Input

- `membershipId`
- optional `resumedAt`

## Preconditions

- Membership must exist.
- Membership must be `PAUSED`.
- Membership must not be cancelled.
- Membership must still be within its membership period.

## Business Rules

- Only paused memberships can be resumed through this use case.
- Suspended memberships cannot be resumed through this use case.
- Suspended memberships for non-payment are reactivated only by the payment received use case.
- Cancelled memberships cannot be resumed.
- If the membership period has already ended, the membership cannot be resumed.
- Membership status becomes `ACTIVE`.
- The pause is closed or cleared.
- Billing references are not changed.
- Payment state is not changed.

## Expected Result

- Membership status changes from `PAUSED` to `ACTIVE`.
- Pause state is closed or cleared.
- Response contains:
  - membership id
  - previous status
  - new status
  - resumed date

## Suggested Implementation Tasks

- Load membership.
- Validate membership is paused.
- Validate membership is not past its end date.
- Apply `membership.resume(...)`.
- Save membership.
- Return resume response.

## Architecture Discussion Points

- Resume is not the same as payment reactivation.
- Keep the distinction between `resume()` and `reactivateAfterPayment()`.
- This helps demonstrate why precise domain language matters.
