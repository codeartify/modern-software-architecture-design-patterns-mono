# Exercise Story: Suspend Overdue Memberships

## Goal

As the system, I want to suspend active memberships with overdue open billing references so that unpaid memberships can no longer be treated as active.

## Trigger

`POST /memberships/suspend-overdue`

## Input

Optional:

- `checkedAt`

If `checkedAt` is missing, the current time is used.

## Preconditions

- Memberships may exist.
- Billing references may exist.

## Business Rules

- Only memberships with status `ACTIVE` are checked for suspension.
- A membership is suspended only when it has an `OPEN` billing reference whose due date is before the checked date.
- A membership that is already suspended for non-payment is not suspended again.
- Memberships that are not active are ignored.
- The suspension reason is non-payment.
- The checked date is derived from `checkedAt` in UTC.

## Expected Result

- Matching active memberships become suspended for non-payment.
- Response contains:
  - `checkedAt`
  - number of checked active memberships
  - ids of suspended memberships

## Suggested Implementation Tasks

- Determine checked timestamp.
- Convert checked timestamp to local date in UTC.
- Load all memberships.
- Load all open billing references.
- For each active membership:
  - find overdue open billing reference
  - suspend membership for non-payment if applicable
  - save membership
- Return suspension summary.

## Architecture Discussion Points

- This is a time-based lifecycle use case.
- The use case coordinates memberships and billing references.
- The rule “active + open overdue billing reference => suspended for non-payment” belongs in business/domain logic.
