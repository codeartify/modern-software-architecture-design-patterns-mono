# Exercise Story: Payment Received

## Goal

As the system, I want to record a received payment so that the local billing reference is marked as paid and the membership may be reactivated if appropriate.

## Trigger

`POST /memberships/payment-received`

## Input

At least one of:

- `externalInvoiceId`
- `externalInvoiceReference`
- `membershipId`

Optional:

- `paidAt`

If `paidAt` is missing, the current time is used.

## Preconditions

- At least one invoice or membership identifier must be provided.
- A matching billing reference must exist.
- The membership belonging to the billing reference must exist.

## Business Rules

- A billing reference is looked up by:
  1. external invoice id
  2. external invoice reference
  3. membership id
- If no billing reference is found, return `404 Not Found`.
- If the billing reference is already paid, do not mark it paid again.
- If the billing reference is not paid, mark it as paid at `paidAt`.
- Payment recording is idempotent.
- Payment does not blindly activate the membership.
- A membership is reactivated only when:
  - it is suspended for non-payment
  - and `paidAt` is not after the membership end date
- If the membership is active, paused, cancelled, expired, or suspended for another reason, payment is recorded but membership status stays unchanged.
- A cancelled membership must stay cancelled.
- A payment after membership end date must not reactivate the membership.

## Expected Result

- Billing reference is paid, unless it was already paid.
- Membership may be reactivated.
- Response contains:
  - paid timestamp
  - membership id
  - billing reference id
  - previous membership status
  - new membership status
  - whether the membership was reactivated
  - message

## Suggested Implementation Tasks

- Validate that at least one identifier was provided.
- Find billing reference.
- Mark billing reference as paid if not already paid.
- Load membership.
- Store previous membership status.
- Reactivate only if the membership is suspended for non-payment and still within the membership period.
- Return payment response.

## Architecture Discussion Points

- This is the main comparative example for the workshop.
- It combines gateway lookup, idempotency, state transition, and orchestration.
- The application layer should orchestrate.
- Domain objects should own state transition rules such as `markPaid()` and `reactivateAfterPayment()`.
