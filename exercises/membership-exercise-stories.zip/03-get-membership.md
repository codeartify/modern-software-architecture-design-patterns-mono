# Exercise Story: Get Membership

## Goal

As a gym employee, I want to retrieve a single membership so that I can inspect its current state.

## Trigger

`GET /memberships/{membershipId}`

## Input

- `membershipId`

## Preconditions

- Membership must exist.

## Business Rules

- If the membership does not exist, return `404 Not Found`.
- No business state changes happen.

## Expected Result

- Response contains the requested membership.

## Suggested Implementation Tasks

- Parse membership id.
- Load membership from repository.
- Return `404` if missing.
- Map membership to response DTO.
- Return response.

## Architecture Discussion Points

- This is query/read logic.
- This is a good candidate to separate from commands in a CQRS discussion.
