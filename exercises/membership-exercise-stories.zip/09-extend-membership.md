# Exercise Story: Extend Membership

## Goal

As a gym employee, I want to extend a membership so that the customer receives additional membership time.

## Trigger

`POST /memberships/{membershipId}/extend`

## Input

- `membershipId`
- `extensionMonths` or `extensionDays`
- optional `billable`
- optional `reason`

## Preconditions

- Membership must exist.
- Membership must not be cancelled.
- Extension duration must be positive.

## Business Rules

- Active memberships can be extended.
- Paused memberships can be extended.
- Suspended memberships can be extended, but remain suspended.
- Cancelled memberships cannot be extended.
- Extending a membership changes the end date.
- Extending a membership does not automatically change the membership status.
- If the membership was suspended for non-payment, extension does not reactivate it.
- If the extension is billable:
  - create an external invoice
  - create a new local billing reference
  - billing reference starts as `OPEN`
- If the extension is not billable:
  - no invoice is created
  - no billing reference is created
- Existing billing references are not changed.

## Expected Result

- Membership end date is extended.
- Membership status stays unchanged.
- Optional billing reference is created when billable.
- Response contains:
  - membership id
  - previous end date
  - new end date
  - membership status
  - optional billing reference data

## Suggested Implementation Tasks

- Load membership.
- Validate membership is not cancelled.
- Validate extension duration.
- Calculate new end date.
- Apply `membership.extend(...)`.
- Save membership.
- If billable:
  - create external invoice
  - create local billing reference
- Return extension response.

## Architecture Discussion Points

- Extension combines domain logic and optional gateway logic.
- The membership should own the end-date extension rule.
- Invoice creation should stay outside the domain object.
