# Exercise Story: Pause Membership

## Goal

As a gym employee, I want to pause a membership so that the customer can temporarily stop training without cancelling the membership.

## Trigger

`POST /memberships/{membershipId}/pause`

## Input

- `membershipId`
- `pauseStartDate`
- `pauseEndDate`
- optional `reason`

## Preconditions

- Membership must exist.
- Membership must be `ACTIVE`.
- Membership must not be cancelled.
- Membership must not be suspended for non-payment.
- Membership must still be within its membership period.
- Pause start date must not be after pause end date.

## Business Rules

- Only active memberships can be paused.
- A suspended membership cannot be paused.
- A cancelled membership cannot be paused.
- A membership whose end date is already in the past cannot be paused.
- The pause period must be stored.
- Membership status becomes `PAUSED`.
- Payment/billing status is not changed by pausing.
- Open billing references remain open.
- Pausing does not mark invoices as paid or cancelled.
- Optional policy decision:
  - either keep the original membership end date
  - or extend the membership end date by the pause duration

## Expected Result

- Membership status changes from `ACTIVE` to `PAUSED`.
- Pause period is recorded.
- Response contains:
  - membership id
  - previous status
  - new status
  - pause start date
  - pause end date
  - end date

## Suggested Implementation Tasks

- Load membership.
- Validate membership is active.
- Validate date range.
- Apply `membership.pause(...)`.
- Save membership.
- Return pause response.

## Architecture Discussion Points

- This is a pure membership lifecycle rule.
- It should not call the invoice provider.
- It should not send billing emails unless explicitly required.
- The state transition rule belongs in the domain model.
