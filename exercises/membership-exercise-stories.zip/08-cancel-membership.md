# Exercise Story: Cancel Membership

## Goal

As a gym employee, I want to cancel a membership so that the contract is ended and cannot be reactivated accidentally.

## Trigger

`POST /memberships/{membershipId}/cancel`

## Input

- `membershipId`
- optional `cancelledAt`
- optional `reason`

## Preconditions

- Membership must exist.
- Membership must not already be cancelled.

## Business Rules

- A membership can be cancelled from:
  - `ACTIVE`
  - `PAUSED`
  - `SUSPENDED_FOR_NON_PAYMENT`
- Cancelled is a final state.
- A cancelled membership cannot be reactivated by payment.
- A cancelled membership cannot be paused.
- A cancelled membership cannot be resumed.
- A cancelled membership cannot be suspended.
- A cancelled membership cannot be extended.
- Cancellation date is recorded.
- Cancellation reason may be recorded.
- Open billing references are not automatically deleted.
- Payment received after cancellation may still mark a billing reference as paid, but membership status stays `CANCELLED`.

## Expected Result

- Membership status changes to `CANCELLED`.
- Cancellation data is recorded.
- Response contains:
  - membership id
  - previous status
  - new status
  - cancelled date
  - reason

## Suggested Implementation Tasks

- Load membership.
- Validate membership is not already cancelled.
- Apply `membership.cancel(...)`.
- Save membership.
- Return cancellation response.

## Architecture Discussion Points

- This is a strong invariant example.
- `CANCELLED` as final state is a good domain model discussion.
- Payment handling must respect cancellation.
