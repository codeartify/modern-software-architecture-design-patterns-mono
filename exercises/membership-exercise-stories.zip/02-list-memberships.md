# Exercise Story: List Memberships

## Goal

As a gym employee, I want to list memberships so that I can see the current memberships in the system.

## Trigger

`GET /memberships`

## Input

No input.

## Preconditions

None.

## Business Rules

- All stored memberships are returned.
- Membership entities are mapped to response objects.
- No business state changes happen.

## Expected Result

- Response contains all memberships.

## Suggested Implementation Tasks

- Load all memberships from the repository.
- Map each membership to a response DTO.
- Return the list.

## Architecture Discussion Points

- This is mostly query/read logic.
- This can be useful later for CQRS.
- This should not contain lifecycle business rules.
