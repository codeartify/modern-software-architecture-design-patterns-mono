# Membership Exercise Stories

This zip contains small implementable business-rule stories derived from the current mixed membership controller.

The stories are designed for the workshop flow:

1. Activate Membership
2. List Memberships
3. Get Membership
4. Suspend Overdue Memberships
5. Payment Received
6. Pause Membership
7. Resume Membership
8. Cancel Membership
9. Extend Membership
10. Query Memberships / CQRS

The existing controller already implements the core baseline stories:

- Activate Membership
- List Memberships
- Get Membership
- Suspend Overdue Memberships
- Payment Received

The additional stories extend the same membership lifecycle model:

- Pause Membership
- Resume Membership
- Cancel Membership
- Extend Membership

These are intentionally written as implementation-ready markdown specs, not as polished product requirements.
